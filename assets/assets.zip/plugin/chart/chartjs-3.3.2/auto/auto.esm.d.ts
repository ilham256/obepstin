import { Chart } from '../dist/chart.esm';

export * from '../dist/chart.esm';
export default Chart;
